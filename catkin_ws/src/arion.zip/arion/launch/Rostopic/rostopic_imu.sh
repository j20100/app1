#!/bin/bash

clear
rostopic echo /imu/data
