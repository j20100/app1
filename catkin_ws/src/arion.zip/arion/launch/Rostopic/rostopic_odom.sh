#!/bin/bash

clear
rostopic echo /odometry/wheel_odom
