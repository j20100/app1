#!/bin/bash

clear

rostopic echo /odometry/filtered/local
