#!/bin/bash

clear

rostopic echo /odometry/gps
